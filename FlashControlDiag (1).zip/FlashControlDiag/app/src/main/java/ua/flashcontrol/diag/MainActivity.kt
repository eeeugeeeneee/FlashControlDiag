package ua.flashcontrol.diag

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val BG = Color.parseColor("#1B1C1E")
    private val PANEL = Color.parseColor("#26282B")
    private val AMBER = Color.parseColor("#FFB000")
    private val RED = Color.parseColor("#C0392B")
    private val TXT = Color.parseColor("#D8D4CC")
    private val DIM = Color.parseColor("#8A8780")
    private val REQ_CAMERA = 1001

    private lateinit var cm: CameraManager
    private lateinit var reportView: TextView
    private lateinit var testBtn: Button
    private val h = Handler(Looper.getMainLooper())
    private val autoOff = Runnable { setTorch(false) }
    private var torchId: String? = null
    private var torchOn = false
    private var testing = false
    private var testStatus = "ще не запускався"
    private var lastReport = ""

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId != torchId) return
            torchOn = enabled
            updateTestButton()
            if (testing) {
                if (enabled) {
                    testStatus = "система підтвердила ввімкнення (перевір очима, що LED світиться)"
                } else {
                    testStatus += "; вимкнення підтверджено"
                    testing = false
                }
                refresh()
            }
        }

        override fun onTorchModeUnavailable(cameraId: String) {
            if (cameraId != torchId) return
            torchOn = false
            updateTestButton()
            if (testing) {
                testStatus = "ліхтарик недоступний (можливо, зайнятий іншою програмою)"
                testing = false
                refresh()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(20), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "FLASHCONTROL // DIAG"
            setTextColor(AMBER); textSize = 20f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "SURVIVOR OS · діагностика ліхтарика"
            setTextColor(DIM); textSize = 12f; typeface = Typeface.MONOSPACE
            setPadding(0, 0, 0, dp(14))
        })

        testBtn = styled("ТЕСТ ЛІХТАРИКА · 5 с", AMBER) { testTorch() }
        root.addView(testBtn, lp(dp(64)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b1 = styled("ОНОВИТИ", DIM) { refresh() }
        val b2 = styled("КОПІЮВАТИ ЗВІТ", DIM) { copyReport() }
        row.addView(b1, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(6) })
        row.addView(b2, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(6) })
        root.addView(row, lp(dp(52)))

        reportView = TextView(this).apply {
            setTextColor(TXT); textSize = 12f; typeface = Typeface.MONOSPACE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(PANEL)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(reportView) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        refresh() // визначає torchId
        cm.registerTorchCallback(torchCb, h)
    }

    override fun onResume() {
        super.onResume()
        refresh() // оновити статус дозволу (напр., після зміни в налаштуваннях)
    }

    override fun onPause() {
        super.onPause()
        if (torchOn) setTorch(false)
    }

    override fun onDestroy() {
        h.removeCallbacks(autoOff)
        try { cm.unregisterTorchCallback(torchCb) } catch (e: Exception) { }
        super.onDestroy()
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(height: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height).apply {
        bottomMargin = dp(10)
    }

    private fun styled(label: String, color: Int, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(color)
        typeface = Typeface.MONOSPACE
        setAllCaps(false)
        background = GradientDrawable().apply {
            setColor(PANEL); cornerRadius = dp(8).toFloat(); setStroke(dp(2), color)
        }
        setOnClickListener { onClick() }
    }

    private fun updateTestButton() {
        testBtn.text = if (torchOn) "ВИМКНУТИ" else "ТЕСТ ЛІХТАРИКА · 5 с"
        testBtn.setTextColor(if (torchOn) RED else AMBER)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- Дозвіл CAMERA ----------

    private fun hasCameraPermission() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_CAMERA) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startTest()
        } else {
            testStatus = "дозвіл CAMERA відхилено — тест не виконано. " +
                "Дозволь вручну: Налаштування → Програми → FlashControl Diag → Дозволи → Камера"
            toast("Без дозволу CAMERA тест неможливий")
            refresh()
        }
    }

    // ---------- Тест ліхтарика ----------

    private fun testTorch() {
        if (torchOn) { setTorch(false); return }
        if (!hasCameraPermission()) {
            testStatus = "очікую відповідь на запит дозволу CAMERA"
            refresh()
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            return
        }
        startTest()
    }

    private fun startTest() {
        testing = true
        testStatus = "команду ввімкнення відправлено, чекаю підтвердження системи"
        refresh()
        if (setTorch(true)) {
            h.removeCallbacks(autoOff)
            h.postDelayed(autoOff, 5000)
        } else {
            testing = false
        }
    }

    /** Повертає true, якщо система прийняла команду. */
    private fun setTorch(on: Boolean): Boolean {
        val id = torchId
        if (id == null) {
            testStatus = "флеш не знайдено — тест неможливий"
            toast("Флеш не знайдено")
            refresh()
            return false
        }
        return try {
            cm.setTorchMode(id, on)
            if (!on) h.removeCallbacks(autoOff)
            true
        } catch (e: Exception) {
            testStatus = "setTorchMode(${on}) завершився помилкою: ${e.javaClass.simpleName}: ${e.message}"
            torchOn = false
            updateTestButton()
            toast("Помилка тесту: ${e.javaClass.simpleName}")
            refresh()
            false
        }
    }

    // ---------- Звіт ----------

    private fun copyReport() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("FlashControlDiag", lastReport))
        toast("Звіт скопійовано")
    }

    private fun refresh() {
        lastReport = buildReport()
        reportView.text = lastReport
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        fun ln(s: String = "") { sb.append(s).append('\n') }

        ln("== ПРИСТРІЙ ==")
        ln("${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
        ln("Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}")
        ln("Збірка: ${Build.DISPLAY}")
        ln()

        ln("== КАМЕРИ / ФЛЕШ (Camera2) ==")
        var apiLevelsMax = 0
        var chosen: String? = null
        try {
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_BACK -> "задня"
                    CameraCharacteristics.LENS_FACING_FRONT -> "фронтальна"
                    else -> "інша"
                }
                val flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                var line = "id=$id $facing, флеш: ${if (flash) "є" else "немає"}"
                if (flash && Build.VERSION.SDK_INT >= 33) {
                    val max = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL)
                    val def = c.get(CameraCharacteristics.FLASH_INFO_STRENGTH_DEFAULT_LEVEL)
                    line += ", рівні: макс=$max, типовий=$def"
                    if (max != null && max > apiLevelsMax) apiLevelsMax = max
                }
                ln(line)
                if (flash && chosen == null) chosen = id
            }
        } catch (e: Exception) {
            ln("Помилка читання камер: ${e.javaClass.simpleName}")
        }
        torchId = chosen
        if (Build.VERSION.SDK_INT < 33) {
            ln("Офіційний API яскравості ліхтарика потребує Android 13+ (API 33); тут його немає.")
        }
        ln()

        ln("== ДОЗВІЛ ==")
        ln("CAMERA: ${if (hasCameraPermission()) "надано" else "не надано"}")
        ln()

        ln("== ТЕСТ ЛІХТАРИКА ==")
        ln(testStatus)
        ln()

        ln("== SYSFS LED (лише читання/перевірка доступу, запису немає) ==")
        val writableNodes = mutableListOf<String>()
        val names = File("/sys/class/leds").list()
        if (names == null) {
            ln("Каталог /sys/class/leds недоступний для застосунку.")
        } else {
            val hits = names.filter { Regex("(?i)torch|flash|white").containsMatchIn(it) }.sorted().take(8)
            if (hits.isEmpty()) ln("Підходящих записів не знайдено.")
            for (n in hits) {
                val d = File("/sys/class/leds/$n")
                val max = try { File(d, "max_brightness").readText().trim() } catch (e: Exception) { "нечитне" }
                val w = File(d, "brightness").canWrite()
                if (w) writableNodes.add(n)
                ln("$n: max=$max, canWrite=${if (w) "так" else "ні"}")
            }
        }
        ln()

        ln("== ВИСНОВОК ==")
        ln("Флеш: ${if (chosen != null) "є (id=$chosen)" else "НЕ знайдено"}")
        val apiLine = when {
            Build.VERSION.SDK_INT < 33 -> "відсутній (потрібен Android 13+)"
            apiLevelsMax > 1 -> "система ЗАЯВЛЯЄ $apiLevelsMax рівнів; на практиці цей застосунок не перевіряв"
            else -> "рівні яскравості не заявлено"
        }
        ln("Офіційний API яскравості: $apiLine")
        val sysLine = if (writableNodes.isEmpty()) {
            "записуваних вузлів не виявлено"
        } else {
            "canWrite=так для: ${writableNodes.joinToString()} — це лише права доступу, НЕ доказ керування яскравістю"
        }
        ln("Sysfs: $sysLine")
        ln()
        when {
            apiLevelsMax > 1 && Build.VERSION.SDK_INT >= 33 ->
                ln("Підсумок: є заявлена підтримка через API; потрібен окремий практичний тест рівнів.")
            writableNodes.isNotEmpty() ->
                ln("Підсумок: регулювання яскравості НЕ підтверджено. Sysfs — лише потенційний шлях; діагностика не пише в системні файли, тож ефект невідомий.")
            else ->
                ln("Підсумок: жодного підтвердженого дозволеного шляху регулювання яскравості не виявлено.")
        }
        return sb.toString()
    }
}

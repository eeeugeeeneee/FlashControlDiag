# FlashControlDiag
Діагностика ліхтарика (Redmi 9). Без root, без інтернету, без запису в системні файли.

Статус: код НЕ компілювався автором; перша збірка — у GitHub Actions або Android Studio.

## Зібрати APK
**Варіант A (GitHub Actions):** створи репозиторій, завантаж ВЕСЬ вміст папки, включно з
прихованою `.github`, `gradlew` і `gradle/`. Гілка `main` → Actions → Build APK → Run workflow →
артефакт `FlashControlDiag-apk` (`app-debug.apk`).
Якщо `.github` не завантажилась через браузер — створи файл `.github/workflows/build.yml` вручну
(Add file → Create new file) і встав туди вміст з архіву.

**Варіант B (Android Studio):** Open → ця папка → Build → Build APK(s).

## Використання
Натисни «ТЕСТ ЛІХТАРИКА»: за першого разу з'явиться запит дозволу «Камера» (потрібен для керування ліхтариком на частині прошивок).
Звіт можна скопіювати кнопкою й надіслати.
